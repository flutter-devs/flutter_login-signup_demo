


final String SIGN_IN = 'signin';
final String SIGN_UP ='signup';
final String SPLASH_SCREEN ='splashscreen';
